/*
 * grunt-git
 * https://github.com/rubenv/grunt-git
 *
 * Copyright (c) 2013 Ruben Vermeersch
 * Licensed under the MIT license.
 */

'use strict';

module.exports = function (grunt) {
    var Config = {};
    //JS Hint
    Config.jshint = {
        options: {
            jshintrc: '.jshintrc' 
        }, all: ['Gruntfile.js']
    };   

    Config.git_ftp = {
        development: {
            options: {
                'host_file':'.gitftppass'
            }
        }
    };

    //Init Task
    grunt.initConfig(Config);

    // Load libs  
    grunt.loadNpmTasks('grunt-contrib-jshint');

    // Load libs  
    grunt.loadNpmTasks('grunt-git-ftp');

    // Register the default tasks
    grunt.registerTask('default', [
        'jshint','git_ftp'
    ]); 
};